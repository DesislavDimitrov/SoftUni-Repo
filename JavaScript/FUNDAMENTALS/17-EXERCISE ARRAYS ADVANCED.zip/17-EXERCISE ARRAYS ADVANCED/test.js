let array = [1, 21, 3, 52, 69, 63, 31, 2, 18, 94];

//array = array.filter(function (x){ return x % 2 === 1});

array.sort((a , b) => b-a)

console.log(array);